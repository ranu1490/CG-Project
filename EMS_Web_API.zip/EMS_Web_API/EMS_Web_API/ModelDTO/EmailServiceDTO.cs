﻿namespace EMS_Web_API.ModelDTO
{
    public class EmailServiceDTO
    {
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string Body { get; set; }
    }
}
