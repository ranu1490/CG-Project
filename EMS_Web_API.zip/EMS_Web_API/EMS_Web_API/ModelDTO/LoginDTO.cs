﻿namespace EMS_Web_API.ModelDTO
{
    public class LoginDTO
    {
        public string Email { get; set; }

        public string Pass { get; set; }
    }
}
